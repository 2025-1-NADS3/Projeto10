package com.example.edupay;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    private EditText etPerfilNome, etPerfilEmail, etPerfilCPF, etPerfilTelefone, etPerfilNascimento;
    private Button btnAtualizarPerfil, btnExcluirConta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        inicializarViews();
        carregarDadosUsuario();

        btnAtualizarPerfil.setOnClickListener(v -> atualizarPerfil());

        btnExcluirConta.setOnClickListener(v -> confirmarExclusao());
    }

    private void inicializarViews() {
        etPerfilNome = findViewById(R.id.etPerfilNome);
        etPerfilEmail = findViewById(R.id.etPerfilEmail);
        etPerfilCPF = findViewById(R.id.etPerfilCPF);
        etPerfilTelefone = findViewById(R.id.etPerfilTelefone);
        etPerfilNascimento = findViewById(R.id.etPerfilNascimento);

        btnAtualizarPerfil = findViewById(R.id.btnAtualizarPerfil);
        btnExcluirConta = findViewById(R.id.btnExcluirConta);
    }

    private void carregarDadosUsuario() {
        // TODO: Buscar dados do usuário atual do banco de dados ou API
        // Simulação de dados carregados
        etPerfilNome.setText("João Silva");
        etPerfilEmail.setText("joao.silva@email.com");
        etPerfilCPF.setText("123.456.789-00");
        etPerfilTelefone.setText("(11) 91234-5678");
        etPerfilNascimento.setText("01/01/1990");
    }

    private void atualizarPerfil() {
        String nome = etPerfilNome.getText().toString().trim();
        String email = etPerfilEmail.getText().toString().trim();
        String cpf = etPerfilCPF.getText().toString().trim();
        String telefone = etPerfilTelefone.getText().toString().trim();
        String nascimento = etPerfilNascimento.getText().toString().trim();

        if (nome.isEmpty() || email.isEmpty() || cpf.isEmpty() || telefone.isEmpty() || nascimento.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: Enviar dados atualizados para backend ou salvar no banco SQLite
        Toast.makeText(this, "Perfil atualizado com sucesso!", Toast.LENGTH_LONG).show();
    }

    private void confirmarExclusao() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir conta")
                .setMessage("Tem certeza que deseja excluir sua conta?")
                .setPositiveButton("Sim", (dialog, which) -> excluirConta())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void excluirConta() {
        // TODO: Implementar exclusão da conta no backend ou banco local
        Toast.makeText(this, "Conta excluída com sucesso!", Toast.LENGTH_LONG).show();

        // Após excluir, redireciona para tela de login e finaliza esta activity
        Intent intent = new Intent(PerfilActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
