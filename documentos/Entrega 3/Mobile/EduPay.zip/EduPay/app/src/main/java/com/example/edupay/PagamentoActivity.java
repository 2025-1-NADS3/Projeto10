package com.example.edupay;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PagamentoActivity extends AppCompatActivity {

    private Button btnPagar;
    private TextView tvStatusPagamento;

    private boolean pago = false; // Simulação do estado do boleto

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);

        btnPagar = findViewById(R.id.btnPagar);
        tvStatusPagamento = findViewById(R.id.tvStatusPagamento);

        btnPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!pago) {
                    pagarBoleto();
                } else {
                    Toast.makeText(PagamentoActivity.this, "Boleto já foi pago!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void pagarBoleto() {
        // Aqui futuramente você chamará o backend para processar o pagamento
        pago = true;

        tvStatusPagamento.setText("Pagamento realizado com sucesso!\nVocê ganhou 10 pontos.");
        btnPagar.setEnabled(false);
        btnPagar.setBackgroundColor(Color.GRAY);  // muda botão para cinza desativado
        Toast.makeText(this, "Pagamento confirmado!", Toast.LENGTH_LONG).show();

        // TODO: Acumular pontos no perfil do usuário (salvar via banco)
    }
}
