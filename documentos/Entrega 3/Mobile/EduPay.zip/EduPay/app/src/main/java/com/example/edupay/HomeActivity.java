package com.example.edupay;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private Button btnPerfil, btnPagamentos, btnFeedback, btnTrocaPontos, btnLogout;
    private TextView tvWelcome;

    private boolean isAdmin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvWelcome = findViewById(R.id.tvWelcome);
        btnPerfil = findViewById(R.id.btnPerfil);
        btnPagamentos = findViewById(R.id.btnPagamentos);
        btnFeedback = findViewById(R.id.btnFeedback);
        btnTrocaPontos = findViewById(R.id.btnTrocaPontos);
        btnLogout = findViewById(R.id.btnLogout);

        // Recebe parâmetro se é admin ou não
        isAdmin = getIntent().getBooleanExtra("isAdmin", false);

        if(isAdmin) {
            tvWelcome.setText("Bem-vindo, Admin EduPay!");
        }

        btnPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, PerfilActivity.class);
            intent.putExtra("isAdmin", isAdmin);
            startActivity(intent);
        });

        btnPagamentos.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, PagamentoActivity.class);
            startActivity(intent);
        });

        btnFeedback.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, FeedbackActivity.class);
            startActivity(intent);
        });

        btnTrocaPontos.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, TrocaPontosActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            // Voltar para login
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }
}
