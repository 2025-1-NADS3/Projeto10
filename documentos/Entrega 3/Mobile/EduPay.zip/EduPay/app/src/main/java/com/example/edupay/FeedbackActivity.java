package com.example.edupay;

import android.os.Bundle;
import android.view.View;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class FeedbackActivity extends AppCompatActivity {

    private ImageView[] stars = new ImageView[5];
    private int rating = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback); // seu arquivo XML

        stars[0] = findViewById(R.id.star1);
        stars[1] = findViewById(R.id.star2);
        stars[2] = findViewById(R.id.star3);
        stars[3] = findViewById(R.id.star4);
        stars[4] = findViewById(R.id.star5);

        for (int i = 0; i < stars.length; i++) {
            final int index = i;
            stars[i].setOnClickListener(view -> {
                rating = index + 1;
                updateStars(rating);
                animateStar(stars[index]);
            });
        }
    }

    private void updateStars(int rating) {
        for (int i = 0; i < stars.length; i++) {
            if (i < rating) {
                stars[i].setImageResource(R.drawable.ic_star); // estrela cheia
            } else {
                stars[i].setImageResource(R.drawable.ic_star_border); // estrela vazia
            }
        }
    }

    private void animateStar(ImageView star) {
        ScaleAnimation scale = new ScaleAnimation(
                0.7f, 1.2f, // de X para X
                0.7f, 1.2f, // de Y para Y
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(200);
        star.startAnimation(scale);
    }
}
