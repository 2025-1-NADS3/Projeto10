package com.example.edupay;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CadastroActivity extends AppCompatActivity {

    private EditText editNameCadastro, editCPF, editCelular, editEmailCadastro, editPasswordCadastro;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro); // seu layout XML de cadastro

        // Vincular os campos do XML com variáveis Java
        editNameCadastro = findViewById(R.id.editNameCadastro);
        editCPF = findViewById(R.id.editCPF);
        editCelular = findViewById(R.id.editCelular);
        editEmailCadastro = findViewById(R.id.editEmailCadastro);
        editPasswordCadastro = findViewById(R.id.editPasswordCadastro);
        btnRegister = findViewById(R.id.btnRegister);

        // Configurar clique do botão para chamar o método de cadastro com validação
        btnRegister.setOnClickListener(v -> {
            String nome = editNameCadastro.getText().toString().trim();
            String cpf = editCPF.getText().toString().trim();
            String celular = editCelular.getText().toString().trim();
            String email = editEmailCadastro.getText().toString().trim();
            String senha = editPasswordCadastro.getText().toString().trim();

            // Validação simples: verifica se algum campo está vazio
            if (nome.isEmpty() || cpf.isEmpty() || celular.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                return;
            }

            cadastrarUsuario(nome, cpf, celular, email, senha);
        });
    }

    // Método que envia os dados para o backend (via POST HTTP)
    private void cadastrarUsuario(String nome, String cpf, String celular, String email, String senha) {
        new Thread(() -> {
            try {
                URL url = new URL("https://b11c74d4-b962-4d3d-ab68-5e2f8b1af269-00-ac7ztsc9rame.kirk.replit.dev/cadastro");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);

                JSONObject jsonInput = new JSONObject();
                jsonInput.put("nome", nome);
                jsonInput.put("cpf", cpf);
                jsonInput.put("celular", celular);
                jsonInput.put("email", email);
                jsonInput.put("senha", senha);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInput.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                if (code == 200) {
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String responseLine;
                        while ((responseLine = br.readLine()) != null) {
                            response.append(responseLine.trim());
                        }
                        runOnUiThread(() -> Toast.makeText(this, "Cadastro realizado!", Toast.LENGTH_SHORT).show());
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Erro no cadastro: " + code, Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
