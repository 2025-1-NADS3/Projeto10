package com.example.edupay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TrocaPontosActivity extends AppCompatActivity {

    private TextView tvPontosUsuario;
    private Button btnCamisa, btnCaneca, btnDesconto, btnCreditoCantina;

    private int pontosUsuario = 120; // Exemplo estático; ideal puxar do backend depois

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_troca_pontos);

        tvPontosUsuario = findViewById(R.id.tvPontosUsuario);
        btnCamisa = findViewById(R.id.btnTrocarCamisa);
        btnCaneca = findViewById(R.id.btnTrocarCaneca);
        btnDesconto = findViewById(R.id.btnTrocarDesconto);
        btnCreditoCantina = findViewById(R.id.btnTrocarCreditoCantina);

        atualizarTextoPontos();

        btnCamisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trocarProduto(100, "Camisa da Faculdade");
            }
        });

        btnCaneca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trocarProduto(80, "Caneca Personalizada");
            }
        });

        btnDesconto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trocarProduto(150, "Desconto na Mensalidade");
            }
        });

        btnCreditoCantina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trocarProduto(50, "Crédito na Cantina");
            }
        });
    }

    private void trocarProduto(int custo, String nomeProduto) {
        if (pontosUsuario >= custo) {
            pontosUsuario -= custo;
            atualizarTextoPontos();
            Toast.makeText(this, "Você trocou por: " + nomeProduto, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Pontos insuficientes para: " + nomeProduto, Toast.LENGTH_SHORT).show();
        }
    }

    private void atualizarTextoPontos() {
        tvPontosUsuario.setText("Você tem " + pontosUsuario + " pontos");
    }
}
